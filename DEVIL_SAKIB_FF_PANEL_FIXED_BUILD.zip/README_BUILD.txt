DEVIL SAKIB FF PANEL — fixed cloud-build project

This ZIP is a SOURCE PROJECT, not an already-built APK.

HOW TO BUILD THE APK USING GITHUB:
1. Download and extract this ZIP.
2. In GitHub, create a new repository. Set it to your default branch (main is recommended).
3. Upload the CONTENTS of the extracted folder to the repository root. Do not upload only the ZIP file.
4. Make sure the .github/workflows/android-debug-apk.yml file is included. If GitHub's web uploader hides .github, create/upload that folder using GitHub's file editor or use GitHub Desktop.
5. Open the repository's Actions tab and enable Actions if prompted.
6. Choose "Build Android APK" and press "Run workflow". If the workflow does not appear, ensure the workflow file is on the repository's default branch and refresh Actions.
7. Wait for the run to finish. A green check means success; a red X means the build failed.
8. Open the successful run, scroll to Artifacts, and download DEVIL-SAKIB-FF-PANEL-APK.
9. Extract that downloaded artifact ZIP; it contains app-debug.apk.

If the run fails, open the failed run and share the error log so the build can be diagnosed.

App name: DEVIL SAKIB FF PANEL
Package ID: com.devilsakib.ffpanel
Minimum Android: Android 6.0 (API 23)

The project wraps its bundled HTML in an Android WebView. It is not connected to or modifying Free Fire.
